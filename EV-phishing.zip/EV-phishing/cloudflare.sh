#!/bin/bash

# Cloudflare Tunnel Setup Script for Phishing Framework
# This exposes your localhost to the internet via Cloudflare

echo "🔥 Phishing Framework - Cloudflare Tunnel Setup"

# Check if cloudflared is installed
if ! command -v cloudflared &> /dev/null; then
    echo "Installing cloudflared..."
    
    # Detect OS and install
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux
        curl -L --output cloudflared.deb https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
        sudo dpkg -i cloudflared.deb
        rm cloudflared.deb
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        brew install cloudflared
    else
        echo "Please install cloudflared manually from https://github.com/cloudflare/cloudflared/releases"
        exit 1
    fi
fi

# Check if server is running
if ! curl -s http://localhost:5000/health > /dev/null; then
    echo "⚠️  Flask server is not running on port 5000!"
    echo "Start it first with: python3 app.py"
    exit 1
fi

echo "🚀 Starting Cloudflare tunnel..."
echo "Your phishing site will be available at:"

# Start tunnel
cloudflared tunnel --url http://localhost:5000

# Note: The URL will be printed once connected
# It will look like: https://something.trycloudflare.com